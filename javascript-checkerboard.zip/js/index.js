function squareAlore(){
  let sec= document.querySelector('section');

  for(let i=0;i<55;i++){
    let div=document.createElement('div');
    div.setAttribute('id','div_'+i);
     if(i%2==0){
      div.setAttribute('style','background-color:green');
    }
    sec.appendChild(div);
  }
}
squareAlore();